
"""
Name: Bashshar Bin Atif
Started: 12/25/2019
"""
import random
from pygame import*  
init() 
font.init() 
font = font.Font(None, 40)



# Initializing lists
highscore = []
waste = ["bottle", "box", "can", "battery", "phone", "laptop", "bread", "muffin", "cup", "styrofoam container","bottle cap","trump"]
location = ["recycle","recycle","recycle","e-waste","e-waste","e-waste","compost","compost","compost","garbage","garbage","garbage"]
#Initializing Variables
points = 0
delay = 0 
counter = 0 
#Creating the Pygame screen.
SIZE = (1000,500)
screen = display.set_mode(SIZE)
screen.fill(0)
running = True
#Colours 
GRAY  = (174,160,142) 
BLUE1 = (67,125,255)
BLUE = (0,0,255) 
GREEN = (0,255,0) 
BLACK = (0,0,0) 
RED = (255,0,0)
ORANGE = (255,165,0)
BENDER = (89,123,124)
WHITE = (255,255,255)
YELLOW = (255, 254, 176)
#Initializing Booleans 
end = False 
throw = False      
state1 = False 
recycle = False 
garbage = False
compost = False
ewaste = False 
#Initializing States 
MENU_STATE = 1
QUIT_STATE = 3
GAME_STATE = 2
INSTRUCTIONS_STATE = 4 
state = 1
#Initializing Variables
counter = 0
score = 0
max_score = 0
highest_score = 0
x = 1
speed = 5
randomIndex = 1
xR = 500
KEY_RIGHT = False 
KEY_LEFT = False
#Loading up images and sounds 
conveyor = image.load("conveyor.png") 
garbage1 = image.load("garbage.png") 
recycle1 = image.load("recycle.png")
compost1 = image.load("compost.png")
ewaste1 = image.load("ewaste.png")
background = image.load("background (3).png")
menu = image.load("state1.png")
instructions = image.load("instructions.png")
quit = image.load("quit.png")
battery1 = image.load("battery.png")
battery1 = transform.scale(battery1, (50,50))
bottle1 = image.load("bottle.png")
bottle1= transform.scale(bottle1, (50,50))
bottle_cap1 = image.load("bottle_cap.png")
bottle_cap1= transform.scale(bottle_cap1, (50,50))
box1 = image.load("box.png")
box1= transform.scale(box1, (50,50))
bread1 = image.load("bread.png")
bread1= transform.scale(bread1, (50,50))
can1 = image.load("can.png")
can1= transform.scale(can1, (50,50))
cup1 = image.load("cup.png")
cup1= transform.scale(cup1, (50,50))
laptop1 = image.load("laptop.png")
laptop1= transform.scale(laptop1, (50,50))
muffin1 = image.load("muffin.png")
muffin1= transform.scale(muffin1, (50,50))
phone1 = image.load("phone.png")
phone1= transform.scale(phone1, (50,50))
styrofoam_container1 = image.load("styrofoam_container.png")
styrofoam_container1= transform.scale(styrofoam_container1, (50,50))
trump1 = image.load("trump.png")
trump1= transform.scale(trump1, (50,50))
#Playing the theme music
theme = mixer.Sound("theme.wav") 
theme.play()
#Opening the file wtih data. 
numFile = open("highest_score.dat", "r")      
write_score = False
"""
This is milestone 1
while True:    
    counter += 1
    #Delyaing the loop
    pygame.time.delay(delay)
    if counter == 1:
        delay = 5000
    if delay != 10: 
        #To make the delay exponentially lower. 
        delay -= 100
    print (delay)
    #Creating the random indexes for the random lists. 
    randomIndex = random.randint(0,12)
    print("RandomIndex:", (randomIndex))
    print(waste[randomIndex])
    answer = str(location[randomIndex])
    #Checking if the answer is correct.     
    choice = str.lower(input("Where should this item go?: \n"))
    if choice == answer: 
        print("That is correct")
        points += 1 
        print("You have", points, "points")         
    else: 
        print("Game Over.")
        print("You had", points, "points") 
        break 
"""
#Functions for each item, bins, robot, and waste.  
def can(x,y): 
    screen.blit(can1, Rect(int(x),int(y),50,50))
def box(x,y): 
    screen.blit(box1, Rect(int(x),int(y),50,50))

def bottle(x,y):
    screen.blit(bottle1, Rect(x,y,50,50))
    
def battery(x,y):
    screen.blit(battery1, Rect(x,y,50,50))
    
def phone(x,y): 
    screen.blit(phone1, Rect(x,y,50,50))
    
def laptop(x,y): 
    screen.blit(laptop1, Rect(x,y,50,50))
    
    
def bread(x,y): 
    screen.blit(bread1, Rect(x,y,50,50))
    
def muffin(x,y): 
    screen.blit(muffin1, Rect(x,y,50,50))
 
def cup(x,y):
    screen.blit(cup1, Rect(x,y,50,50))
 
def styrofoam_container(x,y):
    screen.blit(styrofoam_container1, Rect(x,y,50,50))
 
def bottle_cap(x,y): 
    screen.blit(bottle_cap1, Rect(x,y,50,50))
    
def trump(x,y):    
    screen.blit(trump1, Rect(x,y,50,50))
     
 


def recycingBin():
    screen.blit(recycle1, Rect(100,50,50,50))
    
def compostBin():
    screen.blit(compost1, Rect(150,50,50,50))
    
    
def garbageBin():
    screen.blit(garbage1, Rect(200,50,50,50))
    
    
def ewasteBin():
    screen.blit(ewaste1, Rect(250,50,50,50))
    
def robot(xR):
    #Body 
    draw.rect(screen, BENDER, Rect(xR,350,50,50))
    #Antenna
    draw.rect(screen, BENDER, Rect(xR+22.5,320,5,30))  
    draw.ellipse(screen, RED, Rect(xR+17.5,310,15,15))    
    #Eyes
    draw.rect(screen, BLACK, Rect(xR+5,360,40,20))
    draw.rect(screen, YELLOW, Rect(xR+10,385,30,10))
    draw.ellipse(screen, YELLOW, Rect(xR+5,362.5,15,15))
    #Mouth
    draw.ellipse(screen, YELLOW, Rect(xR+30,362.5,15,15))
    #Arms
    draw.rect(screen, BENDER, Rect(xR-60,390,60,10))
    draw.rect(screen, BENDER, Rect(xR+50,390,60,10))      

def robot_throw(xR):
    #Body 
    draw.rect(screen, BENDER, Rect(xR,350,50,50))
    #Antenna
    draw.rect(screen, BENDER, Rect(xR+22.5,320,5,30))  
    draw.ellipse(screen, RED, Rect(xR+17.5,310,15,15))    
    #Eyes
    draw.rect(screen, BLACK, Rect(xR+5,360,40,20))
    draw.rect(screen, YELLOW, Rect(xR+10,385,30,10))
    draw.ellipse(screen, YELLOW, Rect(xR+5,362.5,15,15))
    #Mouth
    draw.ellipse(screen, YELLOW, Rect(xR+30,362.5,15,15))
    #Arms
    draw.rect(screen, BENDER, Rect(xR-10,320,10,80))
    draw.rect(screen, BENDER, Rect(xR+50,320,10,80))      
    

#A function which decides which randomIndex is related to which waste item. 
def generateWaste(x,y):
    if (waste[randomIndex]) == "can":
        can(x,y)
    if (waste[randomIndex]) == "box":
        box(x,y)       
    if (waste[randomIndex]) == "bottle":
        bottle(x,y)    
    if (waste[randomIndex]) == "battery":
        battery(x,y)
    if (waste[randomIndex]) == "phone":
        phone(x,y) 
    if (waste[randomIndex]) == "laptop":
        laptop(x,y)
    if (waste[randomIndex]) == "bread":
        bread(x,y) 
    if (waste[randomIndex]) == "muffin":
        muffin(x,y)
    if (waste[randomIndex]) == "cup":
        cup(x,y) 
    if (waste[randomIndex]) == "styrofoam container":
        styrofoam_container(x,y)
    if (waste[randomIndex]) == "bottle cap":
        bottle_cap(x,y) 
    if (waste[randomIndex]) == "trump":
        trump(x,y) 
        
  


       
while True:
    #Reading the file 
    text = numFile.readline()  
    text = text.rstrip("\n")
    #text = text.rstrip(" ")    
    highscore.append(text)
    #breaks the text when there is nothing more to read. 
    highest_score = int(highscore[0])
    if (text == ""):
        break     
            
while running:     
    if (state == (MENU_STATE)): 
        #This is the state where the menu gets shown 
        screen.blit(menu, Rect(0,0,1000,500))
                
        for evnt in event.get():#gets the events
            x1, y1 = mouse.get_pos()#gets the position
            if evnt.type == QUIT: #to exit       
                running=False        
            if evnt.type == MOUSEBUTTONDOWN:
                if (445<y1<480) and (730<x1<965):
                    state = 4 
                    
    if (state == (INSTRUCTIONS_STATE)):
        #This is the state where the instructions get shown 
        
        screen.blit(instructions, Rect(0,0,1000,500))
        
        for evnt in event.get():#gets the events
            x1, y1 = mouse.get_pos()#gets the position
            if evnt.type == QUIT: #to exit     
                running=False        
            if evnt.type == MOUSEBUTTONDOWN:
                if (470<y1<500) and (0<x1<240):
                    state = 2      
                         
           
            
    if (state == (QUIT_STATE)): 
        #This is the state where "game over" is shown        
        screen.blit(quit, Rect(0,0,1000,500))
        score3 = (str(max_score))
        score4 = font.render(score3,True, RED)
        screen.blit(score4, (760, 210)) 
        
        
             
        for evnt in event.get():#gets the events
            x1, y1 = mouse.get_pos()#gets the position
            if evnt.type == QUIT: #to exit       
                running=False     
            if evnt.type == MOUSEBUTTONDOWN:
                print(x1,y1)
                if (470<y1<500) and (0<x1<245):
                    score = 0 
                    state = GAME_STATE  
                
    #This if statement determines if the player has lost 
    if score == -10: 
        state = 3
        
    if state == (GAME_STATE): 
        #This is the game state with all the mechanics 
        for evnt in event.get():#gets the events
            x1, y1 = mouse.get_pos()#gets the position
            if evnt.type == QUIT: #to exit       
                running=False
                #Determines which button was clicked and executes the correct funciton. 
            #DEV TOOL (to animate) 
            if evnt.type == MOUSEBUTTONDOWN:
                print(x1,y1)
            # To check for Keyboard Inputs and move the robot and throw items 
            if evnt.type == KEYDOWN: 
                keys = key.get_pressed()
                if keys[K_r]  and throw==False:
                    if (((xR) < (x+50)) and ((xR) > (x-50))):
                        if "recycle" == location[randomIndex]:
                            posx = xR
                            throw = True
                            recycle = True
                            score += 10
                if keys[K_g]  and throw==False:
                    if (((xR) < (x+50)) and ((xR) > (x-50))):
                        if "garbage" == location[randomIndex]:
                            posx = xR                        
                            throw = True   
                            garbage = True
                            score += 10
                if keys[K_e] and throw==False:
                    if (((xR) < (x+50)) and ((xR) > (x-50))):
                        if "e-waste" == location[randomIndex]:
                            posx = xR                        
                            throw = True     
                            ewaste = True 
                            score += 10   
                if keys[K_c]  and throw==False:
                    if (((xR) < (x+50)) and ((xR) > (x-50))):
                        if "compost" == location[randomIndex]:
                            posx = xR                        
                            throw = True  
                            compost = True 
                            score += 10             
    
                if keys[K_RIGHT]:
                    KEY_RIGHT = True
                if keys[K_LEFT]:
                    KEY_LEFT = True 
            if evnt.type == KEYUP:
                if keys[K_RIGHT]:
                    KEY_RIGHT = False
                if keys[K_LEFT]:
                    KEY_LEFT = False 
        if KEY_RIGHT == True:
            #To keep it from colliding 
            if xR > 950: 
                KEY_RIGHT = False 
                xR = 950
            xR = xR + 5
        if KEY_LEFT == True:
            if xR < 350: 
                KEY_LEFT = False
                xR = 350
            xR = xR - 5
        #Creates the background,bins and the conveyor belt
        screen.blit(background, Rect(0,0,1000,500))   
        screen.blit(conveyor, Rect(0,400,1000,50))                
        recycingBin() 
        compostBin() 
        garbageBin() 
        ewasteBin()
        #Creates the text for your score
        label1 = "YOUR SCORE"
        label2 = font.render(label1, True, RED) 
        score1 = (str(score))
        score2 = font.render(score1,True, RED)
        screen.blit(score2, (280, 260)) 
        screen.blit(label2, (50, 260))   
        #Figures out what is the max score 
        if score > max_score:
            max_score = score
            
        if max_score > highest_score:
            highest_score = max_score
            string_highest_score = str(highest_score)
            write_score = True
            
        #Prints out the max score 
        label3 = "MAX SCORE"
        label4 = font.render(label3, True, RED) 
        score3 = (str(max_score))
        score4 = font.render(score3,True, RED)
        screen.blit(score4, (280, 220)) 
        screen.blit(label4, (50, 220))         
        
        #Prints out the highest score 
        label5 = "MAX SCORE EVER"
        label6 = font.render(label5, True, RED) 
        score5 = (str(highest_score))
        score6 = font.render(score5,True, RED)
        screen.blit(score6, (350, 180)) 
        screen.blit(label6, (50, 180))       
        
        if throw == False:
            robot(xR)                
            if state1 == True: 
                x = 0
                #Creates a random number to create a random object
                randomIndex = random.randint(0,11) 
                state1 = False
            if x > 1000:
                x = 0
                #The score gets reduced by 10 if an object misses the bin 
                score -= 10 
                randomIndex = random.randint(0,11)   
                #Increases the speeds of the object
                if speed < 10: 
                    speed += 1
            x += 0.5*(speed) 
            generateWaste(x,350)
               
        if throw == True:
            #All the awesome math for the parabola
            robot_throw(xR)                
            posx -= 5 
            #These are the vertices 
            if recycle == True: 
                h = 120
            if garbage == True: 
                h = 230 
            if compost == True: 
                h = 170
            if ewaste == True: 
                h = 275
            k = 80
            #The equations 
            a = ((350-k)/((xR-120)**2)) 
            posy = (a)*((((posx)-(h))**2))+(k)
            generateWaste(posx,posy)     
            if ((posx) < (h)):
                #Setting everything so that another item can be created 
                throw = False
                ewaste = False 
                recycle = False 
                garbage = False 
                compost = False 
                state1 = True
    
    display.flip()    
    
if write_score == True: 
    numFile = open ("highest_score.dat", "w")
    numFile.write(string_highest_score)
    numFile.close()
mixer.stop() #Stops the theme music 
quit
